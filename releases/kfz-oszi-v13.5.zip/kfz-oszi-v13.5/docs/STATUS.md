# Projektstatus und Übergabe

Stand: Oktober 2026, Feature-Branch `claude/kfz-oszi-kompendium-vwhkd3` (Branch = V13.4; main = V13.2, Stand 11.10.2026, per Fast-Forward auf 472c8e2; nach main nur mit ausdrücklicher Erlaubnis von Roy).
Eine neue Sitzung beginnt mit: „Lies docs/STATUS.md und mach weiter.“

## Erledigt

| Version | Inhalt |
|---|---|
| V11 | Signalbild-Engine W2 (Modelle in echter Zeit, Achsen = Zeichnung, Bildprüfung `SIG.check`). 20 Sensor- und Lambdakarten umgebaut, 293 Bilder. 96 Korrekturen an Kartentexten. Signal-Katalog (146 Signale) in `docs/`. |
| V12 | 16 neue Sensorkarten, komplett mit Text, 210 Bilder. Kartenschema-Prüfung (28 Felder) in `validateKompendium`. Atlas-Gruppen „Fahrwerk, Komfort & Assistenz“ und „Füllstand & Medien“. Live-Demo erkennt Abläufe. |
| V13 (Schritt 2) | 2a: 18 Aktor-, Zündungs- und Buskarten auf W2 umgebaut (238 Bilder), 132 geprüfte Textkorrekturen. 2b: 18 neue Karten (213 Bilder) für Bordnetz (Ruhestrom, Spannungsfall, 5-V-Referenz, 48 V, DC/DC, Transienten, Lampen-PWM), Ventile (CR-DRV, ZME, Benzin-MSV, VVT, Klima, LPG, AdBlue) und Bus (FlexRay, K-Leitung, SW-CAN, Control Pilot). Kartenkategorien `einspr` und `elektrik`. Live-Demo: Abläufe über zwei Fenster, Tabellenmodelle in Schleife, Triggerpegel in A bei Stromkarten. |

| V13.4 (Schritt 4) | 27 Erklärbilder der Theoriekapitel und 18 Fehlermuster-Bilder auf W2 (3 Gruppen, je Autor → Prüfer → Korrektur → Nachprüfung, alle ohne Blocker); vorhandene Kartenmodelle wiederverwendet, 2 neue Modelle (figAliasSampled, figBattStart); alte Bild-Engine (W/G) entfernt; Werkzeuge FIGPATCH/FDBPATCH (render-card, integrate, API.md §9, workflow-bilder.js); W2-Statuszeile kürzt langen Zustandstext; Kapiteltext CAN-Kurzschluss nach TI präzisiert; „fett“ ohne Beleg aus Zündungstexten entfernt; Atlas-Label Kompression korrigiert. |
| V13.3 (Schritt 3b) | 4 neue Buskarten, 62 Bilder, Autor → Prüfer → Korrektur → Nachprüfung (beide Gruppen Runde 2 ohne Blocker): `ethernet-t1` (10BASE-T1S mit Math CH1−CH2; 100BASE-T1 nur Abgrenzung), `j1850` (VPW und PWM), `can-xl` (Arbitrierung, Datenphase als Band, SIC-XL-Umschaltung), `pp-laden` (J1772-Teiler belegt, Typ-2-Stufen berechnet). Live-Modus (Hardwaretest 18.10. offen): Sweep AUTO, eine Aufnahme je Fenster, Messbereich V/div × 10, Positionsschieber. Katalog: 9 Signale offen (7 Hochvolt, Turbolader-Drehzahl, Resolver). |
| V13.2 (Schritt 3a) | 6 neue Karten, 71 Bilder, nach Autor → Prüfer → Korrektur → Nachprüfung (alle 3 Gruppen in Runde 2 ohne Blocker): `pumpe-duese` (VAG PD Magnetventil, Strom mit BIP, Masseseite 10:1, Piezo-PD als Vergleich), `atg-ventil` (Druckregler 300 Hz PWM/Stromregler mit Dither, Schaltventile), `leerlaufsteller` (Drehsteller 2-/3-polig), `schrittmotor` (IAC, 4-/5-Draht), `ionenstrom` (Saab Trionic, nur Niedervolt-Seite), `cdi` (Pickup, Primär nur mit 100:1). Katalog: MPI-Strombild (inj-saug) und COP-Trigger (zuend-prim) als abgedeckt nachgetragen. |
| V13.1 | Unabhängige Gesamtkontrolle (4 Prüfer je 18 Karten + Herstellerdaten VDS1022I): 1 Blocker (Relais: 500-V-Spitzen über der 400-V-Grenze), 29 Kleinbefunde korrigiert (setup.vdiv passend zum Normalbild, Triggerangaben, Kanalangaben, Massehinweise, Zahlen in Bildtexten). Neues Kartenfeld `tk11` {stufe ok|einschr|nein, hinweis}: Messbarkeit mit 1:1-Tastkopf (54 ok, 12 eingeschränkt, 6 nicht: inj-di, inj-piezo, zuend-prim, bordnetz-48v, transienten, cp-laden). Live-Modus: Haken „nur 1:1-Tastköpfe vorhanden“ (Auto-Setup stellt dann nie 10:1 ein). |

Stand der App: 82 Karten mit 1087 W2-Bildern, dazu 27 Erklärbilder und 18 Fehlermuster-Bilder (W2). 149 Signalmodelle. Keine alte Bild-Engine mehr.
Gerätegrenzen (OWON-Quellen, geprüft): 1:1 max. 40 Vss (≈ ±20 V), 10:1 max. 400 Vss, 5 mV–5 V/div, 1 MΩ, 25 MHz, 100 MS/s, 5000 Punkte;
mitgelieferte Tastköpfe haben einen 1X/10X-Schalter.
Katalog: 9 oszirelevante Signale noch offen (7 Hochvolt – ausgeschlossen bzw. nur Niedervolt-Seite; Turbolader-Drehzahlsensor und Resolver ohne belastbare Quellen).

## Bekannte Grenzen und offene Kleinigkeiten

- Live mit Gerät: Roy meldete „Signale laufen kurz an und bleiben stehen“. Ursache (per Lib-Quelle belegt,
  per Simulation mit nachgebildetem vds1022-Modul bestätigt): `set_trigger` der vds1022-Lib hat den Standard
  `sweep=ONCE`; die Bridge übergab keinen Sweep → Einzelschuss, `fetch_iter` wartet danach auf einen neuen
  Trigger. Fix in `bridge.py`: `sweep=AUTO` (mit Rückfall für alte Lib ohne Parameter). **Hardwaretest am
  VDS1022I steht noch aus (Roy).** Falls es damit nicht behoben ist: Bridge-Log ansehen.
  Nachtrag: Roys Hardwaretest – Kurve läuft (Fix greift), aber ruckelig mit springenden Pulsbreiten. Ursache:
  Bridge wählte die Samplerate aus einer Dekadenleiter (1 ms/div → 1 MS/s → Aufnahme 5 ms, Fenster 10 ms),
  die App setzte zwei unabhängige Aufnahmen aneinander und triggerte per Software über die Naht. Fix: Rate
  = 5000/(10·secdiv) (eine Aufnahme = ein Fenster), Geräte-Trigger auf App-Triggerposition, Header `trig`,
  App zeigt die letzte Aufnahme direkt (Demo/Wiedergabe weiter über Ringpuffer); fps 10 → 20. Node-Test
  der Fensterwahl im Scratchpad, **Hardwaretest erneut offen.**
  Nachtrag 2: Testsignal 5 V/1 kHz zeigte Vpp 984 mV, Max 1,00 V = Begrenzung. Die Lib erwartet `range` als
  Spannung am Tastkopf für 10 Divisionen; die Bridge übergab V/div (2 V/div → ±1 V). Fix: V/div × 10 mit
  Gerätegrenzen 50 mV–50 V × Tastkopffaktor; Header `probe` [1,1] (Lib-Werte sind schon am Tastkopf, die App
  multiplizierte bei 10:1 sonst doppelt), `probeUi` zur Info. **Hardwaretest offen.**
  Wunsch Roy umgesetzt: vertikale Positionsschieber neben dem Schirm (CH1 links, CH2 rechts, ±4 div,
  Doppelklick = Mitte), 0-V-Marken in Kanalfarbe am linken Rand; Zahlenfeld und Schieber synchron.
  **Hardwaretest 23.10.2026 (Roy, Testsignal 5 V/1 kHz):** Kurve läuft dauerhaft und steht stabil (Sweep AUTO und
  eine Aufnahme je Fenster bestätigt). Offen: Amplitude zeigte ~1 V statt 5 V bei 1 V/div, Plateaus stufig –
  Ursache war der Tastkopfschalter auf 10X bei App 1:1 (Vpp 560 mV) – nach Umstellen 5,36 Vss, Max 5,28 V:
  **alle drei Live-Fixes am Gerät bestätigt.** Aufnahme (0,8 s, 200 000 Punkte) nachgemessen: alle Pulsbreiten
  496–504 µs, keine Lücken. „Fehlende Flanken“ waren ein Zeichenfehler der Live-Anzeige (Spalten ohne Verbindung
  zur Nachbarspalte, Flanke auf Spaltengrenze) – behoben in drawDec (Lücke zur Nachbarspalte schließen).
  Offen: Gerät setzt den Triggerpunkt an den Fensteranfang statt auf die übergebene Position (Lib: SET_PRE_TRG
  mit htp); für die Messung unerheblich, Ursache noch nicht geprüft.
- Live-UI (23.10.): Schnellbedienleiste über dem Schirm (V/div, Zeit, Trigger, Run/Stop/Single, gespiegelt
  zur Bedienung) und Trigger-Pegel-Schieber rechts mit Marke „T“ – Wunsch Roy.
- Schritt 3b, bewusst als Beispiel/Modell gekennzeichnet: ethernet-t1 – Beacon-Abstand 14 µs (Pico-Bild),
  Reflexions-/Kopplungs-/Störwerte der Fehlerbilder; j1850 – Entladezeitkonstante F7, PWM-Antwortzeiten aus dem
  VPW-Beispiel; can-xl – Zeiten der ADS/DAS-Umschaltung aus TI-Zeitfenstern, PWM-Symbolhöhe F6, Rahmen
  schematisch; pp-laden – Fahrzeugseite nur für J1772 belegt, Typ-2-Stufen berechnet. Statuszeilen-Kollisionen
  („TYPISCH · SCHEMATISCH“ vs. langer cond-Text) sind ein Werkzeugthema, nicht gelöst.
- Engine-Test deckte beim Einbau einen NaN in `ethernetT1Bus` bei großem t auf (Gleitkomma-Rest im Beacon-Index);
  behoben. Lehre: Modelle immer auch mit dem Node-Test prüfen, nicht nur mit dem Render-Werkzeug.
- Live-Demo (Mock): Signale mit sehr kurzen Pulsen bei langer Zeitbasis (Keyless, PDC, Ruhestrom-Pulse,
  K-Leitung bei 50 ms/div) werden zu grob abgetastet, die Übereinstimmung ist dort niedrig. Ruhestrom
  (20 s/div) liegt außerhalb der Live-Zeitbasis. Kein Kartenfehler.
- Erledigt (nach V13, Branch): setup.trig mit Richtung und Pegel bei lam-heiz, zuend-prim, zuend-sek,
  pwm-ventil, luefter-pwm, relais (aus den Modellen am Triggerpunkt bestimmt); gluehkerze setup nennt CH2;
  starter CH2-Belegung einheitlich beschrieben; zuend-prim profi nur noch BIAT-belegt.
- Noch ohne Beleg: „fett“ als Ursache tiefer/langer Brennlinie im Theorie-Kapitel (Zündung) und im Glossar
  „Brennlinie/Brennspannung“ – Quelle suchen oder streichen.
- Schritt 3a, bewusst als Beispiel gekennzeichnet (Quellenlage dünn): ionenstrom – Form/Lage der
  Verbrennungsimpulse qualitativ; pumpe-duese – Tiefe/Lage des BIP-Knicks, F0-Lage; leerlaufsteller/schrittmotor –
  Tastgrade für Kaltstart/Last, Schrittraten; atg-ventil – Dither-Werte, Pendelform im Stellgliedtest (G4);
  cdi – Pickup-Amplituden, 350 V Ladespannung, Ausschwingen. Kleinbefunde offen (optisch): pumpe-duese G0
  Titelkasten berührt die Spitze, F3 Notizposition; Statuszeilen ionenstrom G2/F2 und cdi G2/F5 knapp.
- Schritt 4, bewusst als Beispiel/Modell gekennzeichnet: svg-battstart (Ri 6 mΩ, τ Generator 0,3 s; Kapitel-
  Richtwert 9,5 V vs. Pico 8,8 V kurzzeitig – beides im Bild genannt), svg-kwnw/-versatz (42° KW, 2 V), svg-masse-
  schlecht (10,5 mΩ), svg-5v-ripple (±0,3 V), svg-can-f3 (Nachschwingen 6 MHz), svg-flexray (Pegel aus Pico-Bild),
  svg-canls/-lin/-canfd (Modellpegel/-raten), FEHLERDB (Beispielwiderstände, E-Gas-Modell, Diagnosepegel 3 V in
  fehlende-induktionsspitze nur Pull-up-Annahme). Zwei Anlassdrehzahlen (174 vs. 240 /min) in svg-relkomp und
  svg-masse-gut stammen aus verschiedenen Kartenmodellen – im Text erklärt. Kleine Label-Kollisionen in
  aktor-blockiert und mechanik-trotz-signal (nur Sollbild betroffen).
- Kleinbefunde der Nachprüfung 2b, bewusst offen (optional): adblue G4/F5 Dosierimpulse verschmelzen bei
  10 s/div; adblue F1/F3 Sollbild-Abgrenzung optisch schwach; sensor-ref F6 ohne Startvorgang; flexray F5
  Statuszeile „CH2 Math“ (Werkzeug); sw-can G1 Notizposition.

## Verfahren (bewährt)

1. Je Gruppe (2 Karten): Autor (Recherche mit WebFetch, Modelle, Bilder, bei neuen Karten der ganze Text) →
   unabhängiger Prüfer (Zweitquellen, jedes Bild ansehen) → Korrektur → Nachprüfung. Vorlagen:
   `tools/w2/workflow-sensorkarten.js` (CARDPATCH) bzw. `tools/w2/workflow-neukarten.js` (NEUKARTE).
2. Prüfwerkzeug: `node tools/w2/render-card.js <datei.js> <ausgabe>` (Playwright; `CHROME_PATH` setzen) bis 0 Fehler.
3. Einbau: `node tools/w2/integrate.js index.html <dateien.js>` (idempotent; erste Karte einer neuen kat
   kommt hinter die verwandte kat, z. B. einspr/elektrik hinter aktor). Erklärbilder/Fehlermuster: FIGPATCH/FDBPATCH
   (API.md §9, Vorlage `tools/w2/workflow-bilder.js`).
4. Bestätigte Textfehler: Patch-JSON prüfen/anwenden mit `node tools/w2/apply-patch.js <patch.json> [--check]`.
5. Prüfkette vor jedem Commit:
   - `node --check` auf alle 5 Script-Blöcke;
   - `node tests/live-logic.test.js` (39) und `node tests/signal-engine.test.js` (11);
   - `node tools/validate.js` (0 Fehler);
   - Signatur `KFZ-OSZI-RS-803792F7BB4A6C59` genau 4×;
   - Regressionstexte: „Lücke: 2 Zähne fehlen“ 2× (svg-versatz, svg-kwnw), je 1× „0,2–1 Ω je nach Hersteller“, „nominal ±~2 V“,
     `id:"lmm-dig"`, `id="oszi-live-logic"`, `id="oszi-live-app"`);
   - Kontaktbögen selbst ansehen.
6. Release: `CACHE_NAME` in `service-worker.js` und Footer „Stand vN“ in `index.html` erhöhen, README und
   `docs/signal-katalog.json` (abgedecktDurch) pflegen, dann `node tools/w2/katalog-md.js`.

## Regeln

- Nichts erfinden: jede Zahl belegt (QUELLEN je Karte) oder per `expect` nachgemessen; sonst „typ./herstellerabhängig“.
- Jede neue Karte braucht `tk11` (Messbarkeit mit 1:1-Tastkopf, Grenze ±20 V am Eingang); `setup.vdiv`/`tdiv`
  (erstgelesene Werte) müssen zum Normalbild gut[0] passen, `setup.trig` braucht Pfeil und Pegel.
- Nie an Airbag-, PSI5- oder Pyrotechnik-Kreisen messen. Hochvolt nur Niedervolt-Seite, mit Qualifikationshinweis.
- Signatur nicht verändern. Keine Tokens/Secrets. Nicht nach main pushen ohne ausdrückliche Erlaubnis.
- Commits: Autor Roy Sperlich, deutschsprachige Meldungen.

## Danach (laut Katalog offen)

- Karten sind mit 3b im Wesentlichen vollständig (MOST bewusst weggelassen: MOST150 optisch, MOST50 nur Altfahrzeuge).
  Offen nur noch Hochvolt (ausgeschlossen, HV-Schütze/HVIL höchstens Niedervolt-Seite), Turbolader-Drehzahl und
  Resolver (Quellenlage prüfen).
- Live-Zeitbasis über 2 s/div hinaus (nur nach Hardwaretest mit dem VDS1022I).
